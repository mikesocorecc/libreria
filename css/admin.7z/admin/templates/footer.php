<footer class="main-footer">
    <strong>Copyright &copy; 2014-2019 <a href="#">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.4
    </div>
  </footer>
  
<!-- jQuery -->
<script src="js/jquery.min.js" integrity="sha512-bnIvzh6FU75ZKxp0GXLH9bewza/OIw6dLVh9ICg0gogclmYGguQJWl8U30WpbsGTqbIiAwxTsbe76DErLq5EDQ==" crossorigin="anonymous"></script>
<!-- Bootstrap 4 -->
<script src="js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap4.min.js"></script>
<script src="js/dataTables.responsive.min.js"></script>
<script src="js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.js"></script>
<!--  AJAX DE REGISTRO --> 
<script src="js/sweetalert2.all.min.js"></script>
<!-- Select2 -->
<script src="js/select2.full.min.js"></script>
<!-- Agregamos nuestro codigo js personalizado -->
<script src="js/admin-ajax.js"></script>
<!--  Login ajax --> 
<script src="js/login-ajax.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>
<!--  Codigo para las librerias --> 
<script src="js/app.js"></script>
</body>
</html>